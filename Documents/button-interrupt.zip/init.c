/*
 * init.c
 *
 *  Created on: 9 nov 2020
 *      Author: clark
 */


#include "init.h"
#include "task_helper.h"
rtems_gpio_irq_state h_btn(void *arg);

rtems_task Init(rtems_task_argument ignored){

uint32_t pin = 7;

rtems_gpio_initialize();
rtems_gpio_bsp_select_input(0,pin, &bsp_specific);
rtems_gpio_bsp_select_output(0,pin,&bsp_specific);
rtems_gpio_bsp_set_resistor_mode(0, 4, PULL_UP);
bsp_interrupt_initialize();

print_to_console("interrupt initialized \n");

rtems_status_code status = rtems_gpio_bsp_enable_interrupt(0, pin, FALLING_EDGE);
if(status != RTEMS_SUCCESSFUL){
	exit(status);
}else {
	print_to_console("interrupt enabled\n");
}

status = rtems_gpio_debounce_switch(pin, rtems_clock_get_ticks_per_second()/10);
if(status != RTEMS_SUCCESSFUL){
	exit(status);
}else{
	print_to_console("debounce function assigned");
}

//TODO verify exit error 22 = RTEMS_NOT_CONFIGURED The given pin has no interrupt configured
status = rtems_gpio_interrupt_handler_install(pin, h_btn, 0);
if(status != RTEMS_SUCCESSFUL){
	exit(status);
}else{
	print_to_console("interrupt handler installed");
}

printf("GPIO configured \n");
fflush(stdout);

//rtems_interval sec = 1 * rtems_clock_get_ticks_per_second();
while(1){
	//polling on status variable
	  if(get_status_interrupt()){
		  print_to_console("button pressed");
		  set_status_interrupt(0);
	  }
//	  rtems_task_wake_after(sec);
}

print_to_console("FINISH");
exit(0);
}

rtems_gpio_irq_state h_btn(void *arg){
	set_status_interrupt(1);
	return IRQ_HANDLED;
}


