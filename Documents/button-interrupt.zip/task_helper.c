/*
 * task_helper.c
 *
 *  Created on: 9 nov 2020
 *      Author: clark
 */

#include "task_helper.h"

static uint32_t interrupt_received = 0;

void print_to_console(const char *string){
	printf("%s",string);
	fflush(stdout);
	return;
}

uint32_t get_status_interrupt(){
	return interrupt_received;
}

void set_status_interrupt(uint32_t value){
	interrupt_received = value;
}
